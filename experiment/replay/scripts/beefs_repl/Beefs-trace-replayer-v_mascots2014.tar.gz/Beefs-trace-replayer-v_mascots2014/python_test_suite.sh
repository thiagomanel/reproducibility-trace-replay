find -name "*test.py" | xargs nosetests
